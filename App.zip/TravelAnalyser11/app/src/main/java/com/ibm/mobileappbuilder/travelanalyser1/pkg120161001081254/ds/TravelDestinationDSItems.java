

package com.ibm.mobileappbuilder.travelanalyser1.pkg120161001081254.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;
import com.ibm.mobileappbuilder.travelanalyser1.pkg120161001081254.R;
import java.util.ArrayList;
import java.util.List;
import ibmmobileappbuilder.util.StringUtils;

// TravelDestinationDSSchemaItem static data
public class TravelDestinationDSItems{

    public static List<TravelDestinationDSSchemaItem> ITEMS = new ArrayList<TravelDestinationDSSchemaItem>();
    public static void addItem(TravelDestinationDSSchemaItem item) {
        ITEMS.add(item);
    }
}


